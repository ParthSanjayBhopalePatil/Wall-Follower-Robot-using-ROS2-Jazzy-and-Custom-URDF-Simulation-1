from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    robot_description = PathJoinSubstitution([
        FindPackageShare('wall_follower_bot'), 'urdf', 'wall_follower_robot.urdf'
    ])

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('ros_gz_sim'), 'launch', 'gz_sim.launch.py'
            ])
        ),
        launch_arguments={'gz_args': '-r empty.sdf'}.items()
    )

    state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{
            'robot_description': ['<?xml version="1.0"?>', ''],
            'use_sim_time': True
        }],
        output='screen'
    )

    # Spawn the URDF after Gazebo has had time to start.
    spawn_robot = TimerAction(
        period=4.0,
        actions=[Node(
            package='ros_gz_sim',
            executable='create',
            arguments=['-name', 'wall_follower_robot', '-file', robot_description],
            output='screen'
        )]
    )

    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/cmd_vel@geometry_msgs/msg/Twist]gz.msgs.Twist',
            '/scan@sensor_msgs/msg/LaserScan[gz.msgs.LaserScan',
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'
        ],
        output='screen'
    )

    controller = Node(
        package='wall_follower_bot',
        executable='wall_follower',
        output='screen'
    )

    return LaunchDescription([gazebo, state_publisher, spawn_robot, bridge, controller])
