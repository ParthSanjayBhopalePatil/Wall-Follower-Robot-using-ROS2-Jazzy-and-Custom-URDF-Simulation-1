WALL FOLLOWER ROBOT — ROS 2 JAZZY
=================================

Files:
1. wall_follower.py              Python LiDAR wall-following controller
2. wall_follower_robot.urdf      Custom two-wheel robot with 2D LiDAR
3. wall_follower.launch.py       Gazebo Harmonic + ROS-Gazebo bridge launch

IMPORTANT
---------
These are the three main project files, not a complete ROS 2 package by themselves.
Create an ament_python package named wall_follower_bot and install the files in
the matching package folders. Your setup.py must install the URDF and launch
file and expose this console script:
    wall_follower = wall_follower.wall_follower:main

Required ROS packages (Ubuntu 24.04 / ROS 2 Jazzy):
    ros-jazzy-ros-gz
    ros-jazzy-robot-state-publisher
    ros-jazzy-ros-gz-bridge
    ros-jazzy-rclpy
    ros-jazzy-sensor-msgs
    ros-jazzy-geometry-msgs

Expected topics:
    /scan       sensor_msgs/msg/LaserScan
    /cmd_vel    geometry_msgs/msg/Twist
    /odom       Gazebo differential-drive odometry

Controller behavior:
- Uses front, right, and right-front LiDAR sectors.
- Turns left when an obstacle is too close in front.
- Otherwise adjusts angular velocity to maintain a right-wall distance.

Build/run after completing the package metadata and install rules:
    cd ~/ros2_ws
    colcon build --symlink-install
    source install/setup.bash
    ros2 launch wall_follower_bot wall_follower.launch.py

Compatibility note:
Gazebo Harmonic plugin names and ROS-Gazebo topic bridging can vary with
installed package versions. Test in simulation and adjust the URDF/plugin
configuration if your local Gazebo setup reports a plugin or topic error.
