#!/usr/bin/env python3
"""
Simple ROS 2 Jazzy wall-following controller.
Subscribes: /scan (sensor_msgs/LaserScan)
Publishes:  /cmd_vel (geometry_msgs/Twist)

This controller follows the right-hand wall. Tune the parameters for your
robot and simulation environment.
"""
import math

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist


def sector_min(msg, center_deg, width_deg=10.0):
    """Return the minimum valid range in a sector centered at center_deg."""
    values = []
    count = len(msg.ranges)
    if count == 0 or msg.angle_increment == 0.0:
        return float('inf')

    half = math.radians(width_deg / 2.0)
    center = math.radians(center_deg)
    for i, distance in enumerate(msg.ranges):
        angle = msg.angle_min + i * msg.angle_increment
        delta = math.atan2(math.sin(angle - center), math.cos(angle - center))
        if abs(delta) <= half and math.isfinite(distance):
            if msg.range_min <= distance <= msg.range_max:
                values.append(distance)
    return min(values) if values else float('inf')


class WallFollower(Node):
    def __init__(self):
        super().__init__('wall_follower')
        self.declare_parameter('desired_wall_distance', 0.60)
        self.declare_parameter('forward_speed', 0.15)
        self.declare_parameter('turn_gain', 1.2)
        self.desired_distance = float(
            self.get_parameter('desired_wall_distance').value)
        self.forward_speed = float(self.get_parameter('forward_speed').value)
        self.turn_gain = float(self.get_parameter('turn_gain').value)

        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.subscription = self.create_subscription(
            LaserScan, '/scan', self.scan_callback, 10)
        self.get_logger().info('Wall follower started; following the right wall.')

    def scan_callback(self, scan):
        front = sector_min(scan, 0.0, 18.0)
        right = sector_min(scan, -90.0, 22.0)
        right_front = sector_min(scan, -45.0, 22.0)

        cmd = Twist()

        # Obstacle directly ahead: turn left until the path is clear.
        if front < 0.55:
            cmd.linear.x = 0.03
            cmd.angular.z = 0.65
        else:
            # Keep a steady distance from the wall on the right.
            if not math.isfinite(right):
                cmd.linear.x = self.forward_speed * 0.6
                cmd.angular.z = -0.35
            else:
                error = self.desired_distance - right
                cmd.linear.x = self.forward_speed
                cmd.angular.z = max(-0.8, min(0.8, self.turn_gain * error))

                # Smoothly turn away if a corner/obstacle is close on the right-front.
                if right_front < 0.40:
                    cmd.angular.z = max(cmd.angular.z, 0.35)

        self.publisher.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = WallFollower()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        stop = Twist()
        node.publisher.publish(stop)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
